package cn.vpclub.upload.manager.common.utils;

/**
 * @author HJ
 */
public class Commond {

    public static final int MAX_PICSIZE = 10 * 1024 *1024;
}
