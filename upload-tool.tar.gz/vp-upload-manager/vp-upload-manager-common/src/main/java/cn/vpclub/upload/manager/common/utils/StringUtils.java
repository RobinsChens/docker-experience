package cn.vpclub.upload.manager.common.utils;

import org.apache.commons.codec.binary.Hex;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;

/**
 * @author HJ
 */
public class StringUtils extends org.springframework.util.StringUtils {
    private static char ch[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    private static char numCh[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

    /**
     * MD5运算法测
     */
    public static final String MD5 = "MD5";

    public static boolean isNotEmpty(Object str) {
        return str != null && !"".equals(str);
    }

    /**
     * 获取数字与字母组成的随机字符串
     *
     * @param length 字符串长度
     * @return 随机字符串
     */
    public static String getNonceStr(Integer length) {
        if (length > 0) {
            // 随机数
            Random random = new Random();
            StringBuffer result = new StringBuffer();
            for (int i = 0; i < length; i++) {
                int num = random.nextInt(ch.length);
                result.append(ch[num]);
            }
            return result.toString();
        } else if (length == 0) {
            return "";
        } else {
            throw new IllegalArgumentException();
        }
    }

    /**
     * 获取由数字组成的随机字符串
     *
     * @param length 字符串长度
     * @return 随机字符串
     */
    public static String getNumberNonceStr(Integer length) {
        StringBuffer result = new StringBuffer();
        String str = "0123456789";
        Random r = new Random();
        for (int i = 0; i < length; i++) {
            int num = r.nextInt(numCh.length);
            result.append(numCh[num]);
        }
        return result.toString();
    }

    /**
     * 对字符串进行MD5加密
     *
     * @param str 需要加密的字符串
     * @return MD5加密后的字符串
     */
    public static String encodeToMD5(String str) {
        return encodeToAlgorithm(str, MD5);
    }

    /**
     * 根据运算法测对字符串进行相应的法则加密
     *
     * @param str       加密字符串
     * @param algorithm 运算法测
     * @return String
     */
    public static String encodeToAlgorithm(String str, String algorithm) {
        if (isEmpty(str)) {
            return null;
        } else {
            try {
                MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
                byte[] digest = messageDigest.digest(str.getBytes());
                return new String(Hex.encodeHex(digest));
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
        }
    }

    /**
     * 判断list是否为空
     *
     * @return Boolean
     */
    public static Boolean isEmptyList(List list) {
        if (list != null && !list.isEmpty()) {
            return false;
        }
        return true;
    }

    public static boolean isEmpty(Object str) {
        return str == null || "".equals(str);
    }

}
