package cn.vpclub.upload.manager.common.utils;

/**
 * Created by XiongShi on 2016/3/29.
 * 支付后台返回值枚举类
 */
public enum ReturnCodeEnum {

    /**
     * 验证token及接口返回码及状态信息(查询成功时不返回状态码和状态信息)
     */
    CODE_1000(1000, "成功"),
    CODE_1001(1001, "无权限访问"),
    CODE_1002(1002, "商户不存在"),
    CODE_1003(1003, "支付方式错误"),
    CODE_1004(1004, "服务器处理异常"),
    CODE_1005(1005, "失败"),
    CODE_1006(1006, "参数不全"),
    CODE_1007(1007, "请求超时"),
    CODE_1100(1100, "交易订单不存在"),
    CODE_1101(1101, "无数据导出"),
    CODE_1102(1102, "token过期"),


    /**
     * 发送短信验证接口返回码及状态信息
     */
    CODE_7001(7001, "验证请求AuthnHead参数错误"),
    CODE_7002(7002, "验证请求AuthnHead没通过"),
    CODE_7010(7010, "没有获取到请求的IP地址"),
    CODE_7011(7011, "IP地址不在允许请求的IP范围之内"),
    CODE_7020(7020, "内容不合法，包含敏感词或【】"),
    CODE_7030(7030, "提交到服务商失败"),
    CODE_7040(7040, "号码在黑名单中"),
    CODE_7050(7050, "手机号码格式错误"),

    /**
     * 图片上次业务状态信息
     */
    CODE_8001(8001,"上传图片路径有误"),
    CODE_8002(8002,"图片唯一标识唯一标识错误"),
    CODE_8003(8003,"图片过大，无法上传"),
    /**
     * 邮件发送返回码及状态信息
     */
    CODE_9001(9001, "邮件名格式有误"),
    CODE_9002(9002, "邮件发送失败"),

    CODE_9003(9003,"参数有误"),
    CODE_9004(9004,"验证失败"),
    CODE_9005(9005,"找回密码失败");


    /**
     * 业务编号
     */
    private Integer code;

    /**
     * 业务值
     */
    private String value;

    private ReturnCodeEnum(Integer code, String value) {
        this.code = code;
        this.value = value;
    }

    public final Integer getCode() {
        return code;
    }

    public final String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return this.code + "=" + this.value;
    }

}
