package cn.vpclub.upload.manager.provider.service;

import cn.vpclub.common.config.common.enums.ImageEnum;
import cn.vpclub.common.config.common.utils.QRUtils;
import cn.vpclub.common.config.common.utils.ValidateCode;
import cn.vpclub.upload.manager.api.UploadService;
import cn.vpclub.upload.manager.api.model.SliceUploadInfo;
import cn.vpclub.upload.manager.api.model.UploadResult;
import com.alibaba.dubbo.config.annotation.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;


@Service(version = "1.0.0")
public class UploadServiceImpl implements UploadService {
    private static Logger logger = LoggerFactory.getLogger(UploadServiceImpl.class);

    @Value("${cloud.server.appId}")
    private int appId;
    @Value("${cloud.server.secretId}")
    private String secretId;
    @Value("${cloud.server.secretKey}")
    private String secretKey;
    @Value("${cloud.server.bucket}")
    private String bucket;


    /**
     * 上传图片by二维码
     */
    @Override
    public UploadResult uploadTwoDimensionImg(String code) {
        //生成二维码图片流
        ByteArrayInputStream fileStream = null;
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(code)) {
            return uInfo;
        } else {
            try {
                byte[] byteData = QRUtils.createQr(code, 200, 200, ImageEnum.png.toString());
                fileStream = new ByteArrayInputStream(byteData);
            } catch (Exception e) {
                e.printStackTrace();
                logger.info("生成二维码失败");
                return uInfo;
            }
            //保存到云服务
            return uploadToCloud(fileStream);
        }
    }

    /**
     * 上传图片by验证码
     */
    @Override
    public UploadResult uploadValidateCodeImg(String code) {
        ByteArrayInputStream fileStream = null;
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(code)) {
            return uInfo;
        } else {
            try {
                byte[] byteData = ValidateCode.render(code, 130, 40);
                fileStream = new ByteArrayInputStream(byteData);
            } catch (Exception e) {
                e.printStackTrace();
                logger.info("生成验证码图片失败");
                return uInfo;
            }
            //保存到云服务
            return uploadToCloud(fileStream);
        }
    }

    /**
     * 将文件流保存到云端
     */
    @Override
    public UploadResult uploadToCloud(InputStream fileStream) {
        SliceUploadInfo.PicCloud pc = new SliceUploadInfo.PicCloud(appId, secretId, secretKey, bucket);
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(fileStream)) {
            return uInfo;
        } else {
            try {
                uInfo = pc.upload(fileStream);
            } catch (Exception e) {
                logger.error("upload error: " + e.getMessage(), e);
            } finally {
                if (null != fileStream) {
                    try {
                        fileStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            if (uInfo != null) {
                System.out.println("upload pic success");
                logger.info("upLoadImg success");
                uInfo.print();
            } else {
                System.out.println("upload pic error, error=" + pc.getError());
                logger.info("upLoadImg error, info is: " + pc.getError());
            }
            return uInfo;
        }
    }

    /**
     * 删除云端文件
     *
     * @param fileId 云端资源的唯一标识
     */
    @Override
    public Boolean deleteFile(String fileId) {
        if (StringUtils.isEmpty(fileId)) {
            return false;
        } else {
            SliceUploadInfo.PicCloud pc = new SliceUploadInfo.PicCloud(appId, secretId, secretKey, bucket);
            //删除图片
            System.out.println("====================delete start=======================");
            int ret = pc.delete(fileId);
            if (ret == 0) {
                System.out.println("delete pic success");
                logger.info("deleteImg return date is: success");
                return true;
            } else {
                System.out.println("delete pic error, error=" + pc.getError());
                logger.info("deleteImg error, info is: " + pc.getError());
                return false;
            }
        }
    }
}