package cn.vpclub.upload.manager.api;


import java.util.List;

/**
 * Created by j on 2016/3/7.
 */
    public interface BaseActionService<T> {

        public List<T> queryBaseAction(T t);

    }
