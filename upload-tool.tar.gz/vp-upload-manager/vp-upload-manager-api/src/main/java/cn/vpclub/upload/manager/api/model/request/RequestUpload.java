package cn.vpclub.upload.manager.api.model.request;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/3/8.
 */
public class RequestUpload implements Serializable {

    private String imgUrl;

    private String fileId;

    /**
     * 二维码链接 或者 验证码
     */
    private String code;

    private String token;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
