package cn.vpclub.upload.manager.api.model.request;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/3/5.
 */
public class PageBaseParam implements Serializable {
    /**
     * 每页查询记录数
     */
    protected Integer pageSize;

    /**
     * 页码
     */
    protected Integer pageNumber;

    /**
     * 查询开始记录行号
     */
    protected Integer startRow;

    public PageBaseParam() {
        super();
    }

    public PageBaseParam(Integer pageSize, Integer pageNumber) {
        super();
        this.pageSize = pageSize;
        this.pageNumber = pageNumber;
        this.startRow = (pageNumber == null ? 0 : pageNumber - 1) * (pageSize == null ? 0 : pageSize);
    }

    /**
     * GET每页查询记录数
     *
     * @return Integer
     */
    public Integer getPageSize() {
        return pageSize;
    }

    /**
     * SET每页查询记录数
     *
     * @param pageSize
     */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * GET页码
     *
     * @return Integer
     */
    public Integer getPageNumber() {
        return pageNumber;
    }

    /**
     * SET页码
     *
     * @param pageNumber
     */
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * GET查询开始记录行号
     *
     * @return Integer
     */
    public Integer getStartRow() {
        return startRow = (this.getPageNumber() == null ? 1 : this.getPageNumber() -1) * (this.getPageSize() == null ? 0 : this.getPageSize());
    }
}

