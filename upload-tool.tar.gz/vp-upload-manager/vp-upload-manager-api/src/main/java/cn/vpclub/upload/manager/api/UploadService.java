package cn.vpclub.upload.manager.api;


import cn.vpclub.upload.manager.api.model.UploadResult;

import java.io.InputStream;

/**
 * Created by j on 2016/3/7.
 */
public interface UploadService {
    /**
     * 二维码图片
     */
    public UploadResult uploadTwoDimensionImg(String code);

    /**
     * 验证码图片
     */
    public UploadResult uploadValidateCodeImg(String code);

    /**
     * 验证码图片
     */
    public UploadResult uploadToCloud(InputStream inputStream);

    /**
     * 删除云端文件
     *
     * @param fileId 云端资源的唯一标识
     */
    public Boolean deleteFile(String fileId);

}
