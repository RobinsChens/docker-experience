package cn.vpclub.upload.manager.api.model.request;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/3/8.
 */
public class RequestUser implements Serializable{
    public RequestUser(){

    }
    private Integer id;

    private String userName;

    private String userUnique;

    private String telePhone;

    private Integer sysid;

    private Integer appid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserUnique() {
        return userUnique;
    }

    public void setUserUnique(String userUnique) {
        this.userUnique = userUnique;
    }

    public String getTelePhone() {
        return telePhone;
    }

    public void setTelePhone(String telePhone) {
        this.telePhone = telePhone;
    }

    public Integer getSysid() {
        return sysid;
    }

    public void setSysid(Integer sysid) {
        this.sysid = sysid;
    }

    public Integer getAppid() {
        return appid;
    }

    public void setAppid(Integer appid) {
        this.appid = appid;
    }
}
