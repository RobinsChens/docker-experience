/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.vpclub.upload.manager.api.model;

import java.io.Serializable;

/**
 * @author jusisli
 * 上传返回参数实体
 */
public class UploadResult implements Serializable {
    public String url; // 资源url
    public String downloadUrl; // 下载url
    public String fileId; // 资源的唯一标识
    public int width;
    public int height;
    public PicAnalyze analyze; //图片分析的结果

    public UploadResult() {
        url = "";
        downloadUrl = "";
        fileId = "";
        width = 0;
        height = 0;
        analyze = new PicAnalyze();
    }

    public void print() {
        System.out.println("url = " + url);
        System.out.println("downloadUrl = " + downloadUrl);
        System.out.println("fileId = " + fileId);
        System.out.println("width = " + width);
        System.out.println("height = " + height);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public PicAnalyze getAnalyze() {
        return analyze;
    }

    public void setAnalyze(PicAnalyze analyze) {
        this.analyze = analyze;
    }
};
