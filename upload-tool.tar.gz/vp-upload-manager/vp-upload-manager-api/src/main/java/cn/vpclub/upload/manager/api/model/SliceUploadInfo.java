/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.vpclub.upload.manager.api.model;

import cn.vpclub.common.config.common.utils.JsonUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.HmacUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * @author jusisli
 * 分片上传实体
 */
public class SliceUploadInfo extends UploadResult {
    public String reqUrl;           //上传使用的url
    public String sign;             //上传使用的签名
    public String session;          //唯一标识此文件传输过程的 id
    public int fileSize;
    public int offset;              //传输的文件位移
    public int sliceSize;           //分片大小
    public boolean finishFlag;       //是否命中秒传

    public SliceUploadInfo() {
        reqUrl = "";
        sign = "";
        session = "";
        fileSize = 0;
        offset = 0;
        sliceSize = 0;
        finishFlag = false;
    }

    public SliceUploadInfo copy() {
        SliceUploadInfo newInfo = new SliceUploadInfo();

        newInfo.reqUrl = reqUrl;
        newInfo.sign = sign;
        newInfo.session = session;
        newInfo.sliceSize = sliceSize;
        newInfo.fileSize = fileSize;
        newInfo.offset = offset;
        newInfo.finishFlag = finishFlag;
        return newInfo;
    }

    public void print() {
        super.print();
        System.out.println("session = " + session);
        System.out.println("fileSize = " + fileSize);
        System.out.println("offset = " + offset);
        System.out.println("sliceSize = " + sliceSize);
    }

    /**
     * @author jusisli
     * 客户端发送请求工具类
     */
    public static class CloudClient {
        protected HttpClient mClient;

        public CloudClient() {
            mClient = new DefaultHttpClient();
            mClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 5 * 1000);
        }

        public String post(String url, Map<String, String> header, Map<String, Object> body, byte[] data) throws UnsupportedEncodingException, IOException {
            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader("accept", "*/*");
            httpPost.setHeader("connection", "Keep-Alive");
            httpPost.setHeader("user-agent", "qcloud-java-sdk");
            if (header != null) {
                for (String key : header.keySet()) {
                    httpPost.setHeader(key, header.get(key));
                }
            }

            if (false == header.containsKey("Content-Type") || header.get("Content-Type").equals("multipart/form-data")) {
                MultipartEntity multipartEntity = new MultipartEntity();
                if (body != null) {
                    for (String key : body.keySet()) {
                        multipartEntity.addPart(key, new StringBody(body.get(key).toString()));
                    }
                }

                if (data != null) {
                    ContentBody contentBody = new ByteArrayBody(data, "qcloud");
                    multipartEntity.addPart("fileContent", contentBody);
                }
                httpPost.setEntity(multipartEntity);
            } else {
                if (data != null) {
                    String strBody = new String(data);
                    StringEntity stringEntity = new StringEntity(strBody);
                    httpPost.setEntity(stringEntity);
                }
            }

            HttpResponse httpResponse = mClient.execute(httpPost);
            int code = httpResponse.getStatusLine().getStatusCode();
            return EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
        }

        public String get(String url, Map<String, String> header, Map<String, String> query) throws IOException {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setHeader("accept", "*/*");
            httpGet.setHeader("connection", "Keep-Alive");
            httpGet.setHeader("user-agent", "qcloud-java-sdk");
            httpGet.setHeader("Host", "web.image.myqcloud.com");
            if (header != null) {
                for (String key : header.keySet()) {
                    httpGet.setHeader(key, header.get(key));
                }
            }


            if (query != null) {
                String paramStr = "";
                for (String key : query.keySet()) {
                    if (!paramStr.isEmpty()) {
                        paramStr += '&';
                    }
                    paramStr += key + '=' + URLEncoder.encode(query.get(key));
                }

                if (url.indexOf('?') > 0) {
                    url += '&' + paramStr;
                } else {
                    url += '?' + paramStr;
                }
            }

            HttpResponse httpResponse = mClient.execute(httpGet);
            return EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
        }
    }

    public static class Demo {
        // appid, access id, access key请去http://app.qcloud.com申请使用
        // 下面的的demo代码请使用自己的appid�
        public static final int APP_ID_V1 = 201437;
        public static final String SECRET_ID_V1 = "AKIDblLJilpRRd7k3ioCHe5JGmSsPvf1uHOf";
        public static final String SECRET_KEY_V1 = "6YvZEJEkTGmXrtqnuFgjrgwBpauzENFG";

        public static final int APP_ID_V2 = 10029968;
        public static final String SECRET_ID_V2 = "AKIDqsaEahj8KP5ufFLOMDACd4TFUZqsp4j3";
        public static final String SECRET_KEY_V2 = "WaCdUBCZOIGt7A5uR9acBcRlLKSRLKhZ";
        public static final String BUCKET = "upload007";        //空间名

        public static final String TEST_URL = "http://b.hiphotos.baidu.com/image/pic/item/8ad4b31c8701a18b1efd50a89a2f07082938fec7.jpg";


        public static void signDemo() {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            long expired = System.currentTimeMillis() / 1000 + 3600;
            String sign = pc.getSign(expired);
            System.out.println("sign=" + sign);

        }

        public static void apiV1Demo(String pic) throws Exception {
            PicCloud pc = new PicCloud(APP_ID_V1, SECRET_ID_V1, SECRET_KEY_V1);
            picBase(pc, pic);
        }

        public static void apiV2Demo(String pic) throws Exception {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            picBase(pc, pic);
        }

        public static void picBase(PicCloud pc, String pic) throws Exception {
            // 上传一张图片
            //1. 直接指定图片文件名的方式
            UploadResult result = pc.upload(pic);
            if (result != null) {
                result.print();
            }
            //2. 文件流的方式
            FileInputStream fileStream = new FileInputStream(pic);
            result = pc.upload(fileStream);
            if (result != null) {
                result.print();
            }
            //3. 字节流的方式
            //ByteArrayInputStream inputStream = new ByteArrayInputStream(你自己的参数);
            //ret = pc.upload(inputStream, result);
            // 查询图片的状态
            PicInfo info = pc.stat(result.fileId);
            if (info != null) {
                info.print();
            }
            // 复制一张图片
            result = pc.copy(result.fileId);
            // 删除一张图片
            int ret = pc.delete(result.fileId);
        }

        public static void sliceUpload(String url) {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            SliceUploadInfo info = pc.simpleUploadSlice(url, 128 * 1024);
            if (info != null) {
                System.out.println("slice upload pic success");
                info.print();
            } else {
                System.out.println("slice upload pic error, error=" + pc.getError());
            }
        }

        public static void pornDemo(String url) {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            PornDetectInfo info = pc.pornDetect(url);
            info.print();
        }
    }

    public static class FileCloudSign {

        /**
         * app_sign    时效性签名
         *
         * @param appId      Qcloud上申请的业务IDhttp://app.qcloud.com
         * @param secret_id  Qcloud上申请的密钥id
         * @param secret_key Qcloud上申请的密钥key
         * @param expired    签名过期时间
         * @return String     生成的签名
         */
        public static String appSign(int appId, String secret_id, String secret_key,
                                     long expired) {
            return appSignBase(appId, secret_id, secret_key, "", expired, "");
        }

        public static String appSignV2(int appId, String secret_id, String secret_key,
                                       String bucket,
                                       long expired) {
            return appSignBase(appId, secret_id, secret_key, bucket, expired, "");
        }

        /**
         * app_sign_once   绑定资源的签名,只有这个资源可以使用
         *
         * @param appId      Qcloud上申请的业务IDhttp://app.qcloud.com
         * @param secret_id  Qcloud上申请的密钥id
         * @param secret_key Qcloud上申请的密钥key
         * @param fileid     签名资源的唯一标示
         * @return String     生成的签名
         */
        public static String appSignOnce(int appId, String secret_id, String secret_key,
                                         String fileid) {
            return appSignBase(appId, secret_id, secret_key, "", 0, fileid);
        }

        public static String appSignOnceV2(int appId, String secret_id, String secret_key,
                                           String bucket,
                                           String fileid) {
            return appSignBase(appId, secret_id, secret_key, bucket, 0, fileid);
        }

        private static String appSignBase(int appId, String secret_id, String secret_key,
                                          String bucket,
                                          long expired, String fileid) {
            if (empty(secret_id) || empty(secret_key)) {
                return null;
            }

            long now = System.currentTimeMillis() / 1000;
            int rdm = Math.abs(new Random().nextInt());
            String plain_text = "";
            if (empty(bucket)) {
                plain_text = String.format("a=%d&k=%s&e=%d&t=%d&r=%d&u=%s&f=%s",
                        appId, secret_id, expired, now, rdm, 0, fileid);
            } else {
                plain_text = String.format("a=%d&b=%s&k=%s&e=%d&t=%d&r=%d&u=%s&f=%s",
                        appId, bucket, secret_id, expired, now, rdm, 0, fileid);
            }

            //System.out.println("plain_text="+plain_text);
            byte[] bin = HmacUtils.hmacSha1(secret_key, plain_text);

            byte[] all = new byte[bin.length + plain_text.getBytes().length];
            System.arraycopy(bin, 0, all, 0, bin.length);
            System.arraycopy(plain_text.getBytes(), 0, all, bin.length, plain_text.getBytes().length);

            all = Base64.encodeBase64(all);
            return new String(all);
        }

        public static boolean empty(String s) {
            return s == null || s.trim().equals("") || s.trim().equals("null");
        }

    }

    /**
     * @author jusisli
     *         图片操作方法
     */

    public static class PicCloud {
        private static Logger logger = LoggerFactory.getLogger(PicCloud.class);

        protected static String VERSION = "2.1.4";
        protected static String QCLOUD_DOMAIN = "image.myqcloud.com";
        protected static String PROCESS_DOMAIN = "service.image.myqcloud.com";

        protected int mAppId;
        protected String mSecretId;
        protected String mSecretKey;
        protected String mBucket;

        protected int mErrno;
        protected String mError;

        protected String mMagicContect;

        protected CloudClient mClient;


        /**
         * PicCloud 构造方法
         *
         * @param appId     授权appId
         * @param secretId  授权secret_id
         * @param secretKey 授权secret_key
         */
        public PicCloud(int appId, String secretId, String secretKey) {
            mAppId = appId;
            mSecretId = secretId;
            mSecretKey = secretKey;
            mErrno = 0;
            mBucket = "";
            mError = "";
            mClient = new CloudClient();
        }

        /**
         * PicCloud 构造方法
         *
         * @param appId      授权appId
         * @param secret_id  授权secret_id
         * @param secret_key 授权secret_key
         * @param bucket     空间名
         */
        public PicCloud(int appId, String secret_id, String secret_key, String bucket) {
            mAppId = appId;
            mSecretId = secret_id;
            mSecretKey = secret_key;
            mBucket = bucket;
            mErrno = 0;
            mError = "";
            mClient = new CloudClient();
        }

        public String getVersion() {
            return VERSION;
        }

        public int getErrno() {
            return mErrno;
        }

        public String getErrMsg() {
            return mError;
        }

        public int setError(int errno, String msg) {
            mErrno = errno;
            mError = msg;
            return errno;
        }

        public String getError() {
            return "errno=" + mErrno + " desc=" + mError;
        }

        public void setMagicContext(String context) {
            mMagicContect = context;
        }

        public String getMagicContext() {
            return mMagicContect;
        }

        public String getUrl(String userid, String fileId) {
            String url;
            if ("".equals(mBucket)) {
                url = String.format("http://web.%s/photos/v1/%d/%s", QCLOUD_DOMAIN, mAppId, userid);
            } else {
                url = String.format("http://web.%s/photos/v2/%d/%s/%s", QCLOUD_DOMAIN, mAppId, mBucket, userid);
            }
            if ("".equals(fileId) == false) {
                String params = fileId;
                try {
                    params = URLEncoder.encode(fileId, "ISO-8859-1");
                } catch (UnsupportedEncodingException ex) {
                    System.out.printf("url encode failed, fileId=%s", fileId);
                }
                url += "/" + params;
            }
            return url;
        }

        public String getDownloadUrl(String userid, String fileId) {
            String url;
            if ("".equals(mBucket)) {
                url = String.format("http://%d.%s/%d/%s/%s/original", mAppId, QCLOUD_DOMAIN, mAppId, userid, fileId);
            } else {
                url = String.format("http://%s-%d.%s/%s-%d/%s/%s/original", mBucket, mAppId, QCLOUD_DOMAIN, mBucket, mAppId, userid, fileId);
            }
            return url;
        }

        public JSONObject getResponse(String rsp) {
            if ("".equals(rsp)) {
                setError(-1, "empty rsp");
                return null;
            }
            JSONObject pack = new JSONObject(rsp);
            int code = pack.getInt("code");
            String msg = pack.getString("message");
            if (code != 0) {
                setError(code, msg);
                return null;
            }
            return pack;
        }

        /**
         * Upload 上传图片
         *
         * @param fileName 上传的文件名
         * @return 返回结果
         */
        public UploadResult upload(String fileName) {
            return upload(fileName, "", new PicAnalyze());
        }

        public UploadResult upload(String fileName, String fileId) {
            return upload(fileName, fileId, new PicAnalyze());
        }

        public UploadResult upload(String fileName, String fileId, PicAnalyze flag) {
            if ("".equals(fileName)) {
                setError(-1, "invalid file name");
                return null;
            }

            FileInputStream fileStream = null;
            try {
                fileStream = new FileInputStream(fileName);
            } catch (FileNotFoundException ex) {
                setError(-1, "invalid file name");
                return null;
            }
            return upload(fileStream, fileId, flag);
        }

        public UploadResult upload(InputStream inputStream) {
            return upload(inputStream, "", new PicAnalyze());
        }

        public UploadResult upload(InputStream inputStream, String fileId) {
            return upload(inputStream, fileId, new PicAnalyze());
        }

        public UploadResult upload(InputStream inputStream, String fileId, PicAnalyze flag) {
            String url = getUrl("0", fileId);
            //check analyze flag
            String queryString = "";
            if (flag.fuzzy != 0) {
                queryString += ".fuzzy";
            }
            if (flag.food != 0) {
                queryString += ".food";
            }
            if ("".equals(queryString) == false) {
                url += "?analyze=" + queryString.substring(1);
            }

            // create sign
            long expired = System.currentTimeMillis() / 1000 + 2592000;
            String sign = getSign(expired);
            if (null == sign) {
                setError(-1, "create app sign failed");
                return null;
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", sign);
            header.put("Host", "web.image.myqcloud.com");
            HashMap<String, Object> body = new HashMap<String, Object>();

            JSONObject rspData = null;
            try {
                byte[] data = new byte[inputStream.available()];
                inputStream.read(data);
                String rsp = mClient.post(url, header, body, data);
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error, rsp=" + rsp);
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            UploadResult info = new UploadResult();
            try {
                info.url = rspData.getString("url");
                info.downloadUrl = rspData.getString("download_url");
                info.fileId = rspData.getString("fileid");

                if (rspData.has("info") && rspData.getJSONArray("info").length() > 0) {
                    info.width = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("width");
                    info.height = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("height");
                }

                if (rspData.has("is_fuzzy")) {
                    info.analyze.fuzzy = rspData.getInt("is_fuzzy");
                }
                if (rspData.has("is_food")) {
                    info.analyze.food = rspData.getInt("is_food");
                }
            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }

            setError(0, "success");
            return info;
        }

        /**
         * 分片上传接口族
         *
         * @param fileName 上传的文件名
         * @return 返回结果
         */
        public SliceUploadInfo simpleUploadSlice(String fileName) {
            return simpleUploadSlice(fileName, "", 0);
        }

        public SliceUploadInfo simpleUploadSlice(String fileName, int sliceSize) {
            return simpleUploadSlice(fileName, "", sliceSize);
        }

        public SliceUploadInfo simpleUploadSlice(String fileName, String fileId, int sliceSize) {
            int fileSize = 0;
            FileInputStream fs;
            byte[] data = null;
            try {
                fs = new FileInputStream(fileName);
                fileSize = fs.available();
                data = new byte[fileSize];
                fs.read(data);
                fs.close();
            } catch (Exception e) {
                setError(-1, "read file failed");
                return null;
            }


            SliceUploadInfo info = initUploadSlice(fileId, data, fileSize, sliceSize);
            if (null == info) {
                return info;
            }

            while (false == info.finishFlag) {
                SliceUploadInfo newInfo = UploadSlice(data, info);
                if (newInfo == null) {
                    setError(-1, "slice upload failed, need retry");
                    return null;
                }
                info = newInfo;
            }

            setError(0, "success");
            return info;
        }

        public SliceUploadInfo simpleUploadSlice(String fileName, SliceUploadInfo lastInfo) {
            FileInputStream fs;
            byte[] data = null;
            try {
                fs = new FileInputStream(fileName);
                data = new byte[fs.available()];
                fs.read(data);
                fs.close();
            } catch (Exception e) {
                setError(-1, "read file failed");
                return null;
            }

            SliceUploadInfo info = initUploadSlice(lastInfo.fileId, data, lastInfo.fileSize, lastInfo.sliceSize, lastInfo.session);
            if (null == info) {
                return info;
            }

            int maxRetry = 3;
            while (false == info.finishFlag) {
                int retry = 0;
                while (retry < maxRetry) {
                    retry++;
                    SliceUploadInfo newInfo = UploadSlice(data, info);
                    if (newInfo != null) {
                        info = newInfo;
                        break;
                    }
                }
                if (retry >= maxRetry) {
                    setError(-1, "slice upload failed, need retry");
                    return null;
                }
            }

            setError(0, "success");
            return info;
        }

        public SliceUploadInfo initUploadSlice(String fileId, byte[] data, int fileSize, int sliceSize) {
            return initUploadSlice(fileId, data, fileSize, sliceSize, "");
        }

        public SliceUploadInfo initUploadSlice(String fileId, byte[] data, int fileSize, int sliceSize, String session) {
            SliceUploadInfo info = new SliceUploadInfo();
            //获得文件大小和sha
            String sha = DigestUtils.sha1Hex(data);
            // create sign
            long expired = System.currentTimeMillis() / 1000 + 2592000;
            String sign = getSign(expired);
            if (null == sign) {
                setError(-1, "create app sign failed");
                return null;
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", sign);
            header.put("Host", "web.image.myqcloud.com");
            HashMap<String, Object> body = new HashMap<String, Object>();
            body.put("op", "upload_slice");
            body.put("sha", sha);
            body.put("filesize", fileSize);
            if (sliceSize > 0) {
                body.put("slice_size", sliceSize);
            }
            if ("".equals(session)) {
                body.put("session", session);
            }

            String url = getUrl("0", fileId);
            JSONObject rspData = null;
            try {
                String rsp = mClient.post(url, header, body, null);
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error, rsp=" + rsp);
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            try {
                if (rspData.has("url")) {
                    //命中秒传
                    info.finishFlag = true;
                    info.url = rspData.getString("url");
                    info.downloadUrl = rspData.getString("download_url");
                    info.fileId = rspData.getString("fileid");
                    if (rspData.has("info") && rspData.getJSONArray("info").length() > 0) {
                        info.width = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("width");
                        info.height = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("height");
                    }
                } else if (rspData.has("session")) {
                    info.finishFlag = false;
                    info.reqUrl = url;
                    info.sign = sign;
                    info.session = rspData.getString("session");
                    info.fileSize = fileSize;
                    info.offset = rspData.getInt("offset");
                    info.sliceSize = rspData.getInt("slice_size");
                } else {
                    setError(-1, "qcloud api response data error");
                    return null;
                }
            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }
            return info;
        }

        public SliceUploadInfo UploadSlice(byte[] data, SliceUploadInfo info) {
            if (info.finishFlag) {
                setError(0, "success");
                return info;
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", info.sign);
            header.put("Host", "web.image.myqcloud.com");
            HashMap<String, Object> body = new HashMap<String, Object>();
            body.put("op", "upload_slice");
            body.put("session", info.session);
            body.put("offset", info.offset);

            JSONObject rspData = null;
            try {
                int from = info.offset;
                int to = info.offset + info.sliceSize;
                to = to > info.fileSize ? info.fileSize : to;
                byte[] sliceData = Arrays.copyOfRange(data, from, to);
                String rsp = mClient.post(info.reqUrl, header, body, sliceData);
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error, rsp=" + rsp);
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            SliceUploadInfo newInfo = new SliceUploadInfo();
            try {
                if (rspData.has("url")) {
                    //上传完成
                    newInfo.finishFlag = true;
                    newInfo.url = rspData.getString("url");
                    newInfo.downloadUrl = rspData.getString("download_url");
                    newInfo.fileId = rspData.getString("fileid");
                    if (rspData.has("info") && rspData.getJSONArray("info").length() > 0) {
                        newInfo.width = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("width");
                        newInfo.height = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("height");
                    }
                } else if (rspData.has("session")) {
                    newInfo.finishFlag = false;
                    newInfo.reqUrl = info.reqUrl;
                    newInfo.sign = info.sign;
                    newInfo.session = rspData.getString("session");
                    newInfo.offset = rspData.getInt("offset") + info.sliceSize;
                    newInfo.sliceSize = info.sliceSize;
                    newInfo.fileSize = info.fileSize;
                    //newInfo.sliceSize = rspData.getInt("slice_size");
                } else {
                    setError(-1, "qcloud api response data error");
                    return null;
                }
            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }

            setError(0, "success");
            return newInfo;
        }

        /**
         * Delete 删除图片
         *
         * @param fileId 图片的唯一标识
         * @return 错误码，0为成功
         */
        public int delete(String fileId) {
            // create sign once
            String sign = getSignOnce(fileId);
            if (null == sign) {
                return setError(-1, "create app sign failed");
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", sign);
            header.put("Host", "web.image.myqcloud.com");

            String url = getUrl("0", fileId) + "/del";
            try {
                String rsp = mClient.post(url, header, null, null);
                JSONObject rspData = getResponse(rsp);
                if (null == rspData) {
                    return setError(-1, "qcloud api response packet error, rsp=" + rsp);
                }
            } catch (Exception e) {
                return setError(-1, "url exception, e=" + e.toString());
            }

            return setError(0, "success");
        }

        /**
         * Stat 查询图片信息
         *
         * @param fileId 图片fileid
         * @return 返回结果
         */
        public PicInfo stat(String fileId) {
            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Host", "web.image.myqcloud.com");

            String url = getUrl("0", fileId);
            JSONObject rspData = null;
            try {
                String rsp = mClient.get(url, header, null);
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error, rsp=" + rsp);
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            PicInfo info = new PicInfo();
            try {
                info.url = rspData.getString("file_url");
                info.fileId = rspData.getString("file_fileid");
                info.uploadTime = rspData.getInt("file_upload_time");
                info.size = rspData.getInt("file_size");
                info.md5 = rspData.getString("file_md5");
                info.width = rspData.getInt("photo_width");
                info.height = rspData.getInt("photo_height");
            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }

            setError(0, "success");
            return info;
        }

        /**
         * Copy 复制图片
         *
         * @param fileId 图片的唯一标识
         * @return 返回结果
         */
        public UploadResult copy(String fileId) {
            // create sign once
            String sign = getSignOnce(fileId);
            if (null == sign) {
                setError(-1, "create app sign failed");
                return null;
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", sign);
            header.put("Host", "web.image.myqcloud.com");

            String url = getUrl("0", fileId) + "/copy";
            JSONObject rspData = null;
            try {
                String rsp = mClient.post(url, header, null, null);
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error, rsp=" + rsp);
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            UploadResult info = new UploadResult();
            try {
                info.url = rspData.getString("url");
                info.downloadUrl = rspData.getString("download_url");
                info.fileId = info.url.substring(info.url.lastIndexOf('/') + 1);

                if (rspData.has("info") && rspData.getJSONArray("info").length() > 0) {
                    info.width = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("width");
                    info.height = rspData.getJSONArray("info").getJSONObject(0).getJSONObject("0").getInt("height");
                }

            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }

            setError(0, "success");
            return info;
        }

        /**
         * Download 下载图片
         *
         * @param url      图片的唯一标识
         * @param fileName 下载图片的保存路径
         * @return 错误码，0为成功
         */
        public int download(String url, String fileName) {
            JSONObject rspData = null;
            try {
                String rsp = mClient.get(url, null, null);
                File file = new File(fileName);
                DataOutputStream ops = new DataOutputStream(new FileOutputStream(
                        file));
                ops.writeBytes(rsp);
                ops.close();
            } catch (Exception e) {
                return setError(-1, "url exception, e=" + e.toString());
            }

            return setError(0, "success");
        }

        public String getSign(long expired) {
            return FileCloudSign.appSignV2(mAppId, mSecretId, mSecretKey, mBucket, expired);
        }

        public String getSignOnce(String fileId) {
            return FileCloudSign.appSignOnceV2(mAppId, mSecretId, mSecretKey, mBucket, fileId);
        }

        public String getProcessSign(long expired, String url) {
            return PicProcessSign.sign(mAppId, mSecretId, mSecretKey, mBucket, expired, url);
        }

        public PornDetectInfo pornDetect(String url) {
            // create sign
            long expired = System.currentTimeMillis() / 1000 + 3600 * 24;
            String sign = getProcessSign(expired, url);
            if (null == sign) {
                setError(-1, "create app sign failed");
                return null;
            }

            HashMap<String, String> header = new HashMap<String, String>();
            header.put("Authorization", sign);
            header.put("Host", PROCESS_DOMAIN);
            header.put("Content-Type", "application/json");
            //create body
            JSONObject reqData = new JSONObject();
            reqData.put("appid", mAppId);
            reqData.put("bucket", mBucket);
            reqData.put("url", url);

            String reqUrl = "http://" + PROCESS_DOMAIN + "/detection/pornDetect";
            JSONObject rspData = null;
            try {
                String rsp = mClient.post(reqUrl, header, null, reqData.toString().getBytes());
                rspData = getResponse(rsp);
                if (null == rspData || false == rspData.has("data")) {
                    setError(-1, "qcloud api response error");
                    return null;
                }
                rspData = rspData.getJSONObject("data");
            } catch (Exception e) {
                setError(-1, "url exception, e=" + e.toString());
                return null;
            }

            PornDetectInfo info = new PornDetectInfo();
            try {
                info.result = rspData.getInt("result");
                info.confidence = rspData.getDouble("confidence");
                info.pornScore = rspData.getDouble("porn_score");
                info.normalScore = rspData.getDouble("normal_score");
                info.hotScore = rspData.getDouble("hot_score");
            } catch (JSONException e) {
                setError(-1, "json exception, e=" + e.toString());
                return null;
            }
            setError(0, "success");
            return info;
        }

    }

    /**
     * @author jusisli
     * 图片签名
     */
    public static class PicProcessSign {
        public static String sign(int appId, String secret_id, String secret_key,
                                  String bucket,
                                  long expired, String url) {
            //a=[appid]&b=[bucket]&k=[SecretID]&t=[currenTime]&e=[expiredTime]&l=[url link]
            if (empty(secret_id) || empty(secret_key)) {
                return null;
            }

            long now = System.currentTimeMillis() / 1000;
            String plain_text = String.format("a=%d&b=%s&k=%s&t=%d&e=%d&l=%s",
                    appId, bucket, secret_id, now, expired, url);

            byte[] bin = HmacUtils.hmacSha1(secret_key, plain_text);

            byte[] all = new byte[bin.length + plain_text.getBytes().length];
            System.arraycopy(bin, 0, all, 0, bin.length);
            System.arraycopy(plain_text.getBytes(), 0, all, bin.length, plain_text.getBytes().length);

            all = Base64.encodeBase64(all);
            return new String(all);
        }

        public static boolean empty(String s) {
            return s == null || s.trim().equals("") || s.trim().equals("null");
        }
    }

    public static class Test {
        // appid, access id, access key请去http://app.qcloud.com申请使用
        // 下面的的demo代码请使用自己的appid
    //	public static final int APP_ID_V1 = 201437;
    //	public static final String SECRET_ID_V1 = "AKIDblLJilpRRd7k3ioCHe5JGmSsPvf1uHOf";
    //	public static final String SECRET_KEY_V1 = "6YvZEJEkTGmXrtqnuFgjrgwBpauzENFG";
    //
    //        public static final int APP_ID_V2 = 10000001;
    //	public static final String SECRET_ID_V2 = "AKIDNZwDVhbRtdGkMZQfWgl2Gnn1dhXs95C0";
    //	public static final String SECRET_KEY_V2 = "ZDdyyRLCLv1TkeYOl5OCMLbyH4sJ40wp";
    //        public static final String BUCKET = "testb";        //空间名

        public static final int APP_ID_V1 = 201437;
        public static final String SECRET_ID_V1 = "AKIDblLJilpRRd7k3ioCHe5JGmSsPvf1uHOf";
        public static final String SECRET_KEY_V1 = "6YvZEJEkTGmXrtqnuFgjrgwBpauzENFG";

        public static final int APP_ID_V2 = 10029968;
        public static final String SECRET_ID_V2 = "AKIDqsaEahj8KP5ufFLOMDACd4TFUZqsp4j3";
        public static final String SECRET_KEY_V2 = "WaCdUBCZOIGt7A5uR9acBcRlLKSRLKhZ";
        public static final String BUCKET = "upload007";        //空间名

        public static final String TEST_URL = "http://b.hiphotos.baidu.com/image/pic/item/8ad4b31c8701a18b1efd50a89a2f07082938fec7.jpg";

        /*public static void main(String[] args) throws Exception {
            //sign_test();
            //v1版本api的demo
            //picV1Test("D:/sss.jpg");
            //v2版本api的demo
            picV2Test("e:/test123.png");
            //picV2Test("D:/original.jpg");
            //分片上传
            //sliceUpload("D:/testa.jpg");
            //signTest();
            //黄图识别服务
            //pornTest(TEST_URL);

        }*/

        public static void signTest() {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            long expired = System.currentTimeMillis() / 1000 + 3600;
            String sign = pc.getSign(expired);
            System.out.println("sign=" + sign);

        }

        public static void picV1Test(String pic) throws Exception {
            PicCloud pc = new PicCloud(APP_ID_V1, SECRET_ID_V1, SECRET_KEY_V1);
            picBase(pc, pic);
        }

        public static void picV2Test(String pic) throws Exception {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            picBase(pc, pic);
        }

        public static void picBase(PicCloud pc, String pic) throws Exception {
            String url = "";
            String downloadUrl = "";

            // 上传一张图片
            System.out.println("======================================================");
            UploadResult uInfo = pc.upload(pic);
            if (uInfo != null) {
                System.out.println("upload pic success");
                uInfo.print();
            } else {
                System.out.println("upload pic error, error=" + pc.getError());
            }

            FileInputStream fileStream = new FileInputStream(pic);
            uInfo = pc.upload(fileStream);
            if (uInfo != null) {
                System.out.println("upload pic2 success");
                uInfo.print();
            } else {
                System.out.println("upload pic2 error, error=" + pc.getError());
            }

            FileInputStream fileStream2 = new FileInputStream(pic);
            byte[] data = new byte[fileStream2.available()];
            fileStream2.read(data);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            uInfo = pc.upload(inputStream);
            if (uInfo != null) {
                System.out.println("upload pic3 success");
                uInfo.print();
            } else {
                System.out.println("upload pic3 error, error=" + pc.getError());
            }

            // 查询图片的状态
            System.out.println("======================================================");
            PicInfo pInfo = pc.stat(uInfo.fileId);
            if (pInfo != null) {
                System.out.println("Stat pic success");
                System.out.println("pInfo is: " + JsonUtil.objectToJson(pInfo));
                pInfo.print();
            } else {
                System.out.println("Stat pic error, error=" + pc.getError());
            }

            // 复制一张图片
            System.out.println("======================================================");
            uInfo = pc.copy(uInfo.fileId);
            if (uInfo != null) {
                System.out.println("copy pic success");
                uInfo.print();
            } else {
                System.out.println("copy pic error, error=" + pc.getError());
            }

            // 删除一张图片
            System.out.println("======================================================");
            int ret = pc.delete(uInfo.fileId);
            if (ret == 0) {
                System.out.println("delete pic success");
            } else {
                System.out.println("delete pic error, error=" + pc.getError());
            }
        }

        public static void sliceUpload(String url) {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            SliceUploadInfo info = pc.simpleUploadSlice(url, 8 * 1024);
            if (info != null) {
                System.out.println("slice upload pic success");
                info.print();
            } else {
                System.out.println("slice upload pic error, error=" + pc.getError());
            }
        }

        public static void pornTest(String url) {
            PicCloud pc = new PicCloud(APP_ID_V2, SECRET_ID_V2, SECRET_KEY_V2, BUCKET);
            PornDetectInfo info = pc.pornDetect(url);
            if (info != null) {
                System.out.println("detect porn pic success");
                info.print();
            } else {
                System.out.println("detect porn pic error, error=" + pc.getError());
            }
        }
    }
};