/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.vpclub.upload.manager.api.model;

import java.io.Serializable;

/**
 * @author jusisli
 */
public class PicAnalyze implements Serializable {
    public int fuzzy;
    public int food;

    public PicAnalyze() {
        fuzzy = 0;
        food = 0;
    }
};
