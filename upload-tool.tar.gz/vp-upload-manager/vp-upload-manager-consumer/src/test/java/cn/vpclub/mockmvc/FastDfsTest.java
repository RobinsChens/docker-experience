package cn.vpclub.mockmvc;

import cn.vpclub.common.config.common.utils.JsonUtil;
import cn.vpclub.upload.manager.consumer.fastdfs.FastDfsClient;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import sun.misc.BASE64Encoder;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.fileUpload;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * CreatedBy RobinChen
 */
public class FastDfsTest extends BaseMockMvcTest{
	
	/**
	 * 上传测试.
	 * @throws Exception
	 */
	@Test
	public  void upload() throws Exception {
		String filePath = "TestFile/UploadTest.jpg";
		File file = new File(filePath);
		String fileId = FastDfsClient.uploadFile(file, filePath);
		logger.info("Upload local file " + filePath + " ok, fileid=" + fileId);
		// fileId:	group1/M00/00/00/wKgEfVUYPieAd6a0AAP3btxj__E335.jpg
		// url:	http://172.16.5.23:8888/group1/M00/00/00/rBEAA1edr4KAFUZRAAP3btxj__E642.jpg
	}
	/**
	 * 上传测试.
	 * @throws Exception
	 */
	@Test
	public  void uploadByByte() throws Exception {
		String filePath = "TestFile/ByteTest.jpg";
		File file = new File(filePath);
		InputStream input = new FileInputStream(file);
		byte[] byt = new byte[input.available()];

		input.read(byt);

		String fileId = FastDfsClient.uploadFileByByte(byt, filePath);
		logger.info("Upload local file " + filePath + " ok, fileid=" + fileId);
		// fileId:	group1/M00/00/00/wKgEfVUYPieAd6a0AAP3btxj__E335.jpg
		// url:	http://172.16.5.23:8888/group1/M00/00/00/rBEAA1edr4KAFUZRAAP3btxj__E642.jpg
	}
	/**
	 * 下载测试.
	 * @throws Exception
	 */
	@Test
	public  void download() throws Exception {
		String fileId = "group1/M00/00/00/rBEAA1ed1dWAZFuCAAQrOlgyRvc747.jpg";
		InputStream inputStream = FastDfsClient.downloadFile(fileId);
		File destFile = new File("TestFile/DownloadTest.jpg");
		FileUtils.copyInputStreamToFile(inputStream, destFile);
	}

	/**
	 * 删除测试
	 * @throws Exception
	 */
	@Test
	public  void delete() throws Exception {
		String fileId = "group1/M00/00/00/rBEAA1edwwyAV87cAAAlL-rimA8534.jpg";
		int result = FastDfsClient.deleteFile(fileId);
		logger.info(result == 0 ? "删除成功" : "删除失败:" + result);
	}

	@Test
	/**
	 * testALl
	 */
	public void testAll(){

	}

	@Test
	public void mockUpload() throws Exception {
		String uri = "/common/api/file/upload";

		FileInputStream fis = new FileInputStream("TestFile/UploadTest.jpg");
		MockMultipartFile multipartFile = new MockMultipartFile("fileData", fis);
		Map<String, Object> request = new HashMap<String, Object>();
		request.put("action", "imageUpload");
		request.put("origin", "app");
		String inputJson = JsonUtil.objectToJson(request);
		MvcResult result = mockMvc.perform(fileUpload(uri)
				.file(multipartFile).content(inputJson)
				.contentType(MediaType.MULTIPART_FORM_DATA))
				.andExpect(status().isOk()).andReturn();

		String content = result.getResponse().getContentAsString();
		int status = result.getResponse().getStatus();
		logger.info("content: " + content);
		Assert.assertTrue(
				"failure - expected HTTP response body to have a value",
				content.trim().length() > 0);
	}
}
