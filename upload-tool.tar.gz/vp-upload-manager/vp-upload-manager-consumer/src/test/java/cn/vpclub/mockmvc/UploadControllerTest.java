package cn.vpclub.mockmvc;

import cn.vpclub.common.config.common.utils.JsonUtil;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import sun.misc.BASE64Encoder;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by admin on 2016/3/14.
 */
public class UploadControllerTest extends BaseMockMvcTest {

    @Test
    public void TestDeleteImg() throws Exception {
        String fileId = "b0554165-4c45-4bcd-a321-fb00bb76f2a6";
        String url = "/upload/picCloud/deleteImg";
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("fileId", fileId);
        String inputJson = JsonUtil.objectToJson(request);
        logger.info("TestDeleteImg input: " + inputJson);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(inputJson))
                .andExpect(status().isOk())
                .andReturn();
        String content = result.getResponse().getContentAsString();
        int status = result.getResponse().getStatus();
        logger.info("content: " + content);
    }

    @Test
    public void TestImgTwoDimensionUpload() throws Exception {
        String code = "a73106eb-302a-4707-8546-7f2ca6698ed7";
        String url = "/upload/picCloud/imgTwoDimensionUpload";
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("code", code);
        String inputJson = JsonUtil.objectToJson(request);
        logger.info("TestImgTwoDimensionUpload input: " + inputJson);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(inputJson))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        logger.info("content: " + content);
        Assert.assertTrue(
                "failure - expected HTTP response body to have a value",
                content.trim().length() > 0);
    }

    @Test
    public void TestImgValidateCodeUpload() throws Exception {
        String code = "88888";
        String url = "/upload/picCloud/imgValidateCodeUpload";
        Map<String, Object> request = new HashMap<String, Object>();
        request.put("code", code);
        String inputJson = JsonUtil.objectToJson(request);
        logger.info("TestImgValidateCodeUpload input: " + inputJson);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(inputJson))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        int status = result.getResponse().getStatus();
        logger.info("content: " + content);
        Assert.assertTrue(
                "failure - expected HTTP response body to have a value",
                content.trim().length() > 0);
    }

    @Test
    public void TestUpload() throws Exception {
        try {
            InputStream in = new FileInputStream("E:/test123.png");
            byte[] data = new byte[in.available()];
            in.read(data);
            //对字节数组Base64编码
            BASE64Encoder encoder = new BASE64Encoder();
            String imgFile = encoder.encode(data);//返回Base64编码过的字节数组字符串
            String url = "/upload/picCloud/imgUploadByBase64";
            Map<String, Object> request = new HashMap<String, Object>();
            request.put("imgFile", imgFile);
            String inputJson = JsonUtil.objectToJson(request);
            logger.info("TestImgValidateCodeUpload input: " + inputJson);
            MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(url)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(inputJson))
                    .andExpect(status().isOk())
                    .andReturn();

            String content = result.getResponse().getContentAsString();
            logger.info("content: " + content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}