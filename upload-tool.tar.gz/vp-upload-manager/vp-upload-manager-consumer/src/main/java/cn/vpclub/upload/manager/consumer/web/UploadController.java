package cn.vpclub.upload.manager.consumer.web;

import cn.vpclub.common.config.api.model.response.BaseResponse;
import cn.vpclub.common.config.common.utils.HttpResponseUtil;
import cn.vpclub.common.config.common.utils.JsonUtil;
import cn.vpclub.common.config.common.utils.ValidateCode;
import cn.vpclub.upload.manager.api.UploadService;
import cn.vpclub.upload.manager.api.model.PicCloud;
import cn.vpclub.upload.manager.api.model.UploadResult;
import cn.vpclub.upload.manager.api.model.request.RequestUpload;
import cn.vpclub.upload.manager.common.utils.Commond;
import cn.vpclub.upload.manager.common.utils.ReturnCodeEnum;
import cn.vpclub.upload.manager.common.utils.StringUtils;
import com.alibaba.dubbo.config.annotation.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import sun.misc.BASE64Decoder;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author luke zhu
 *         图片操作方法
 *         看着窗外的大雨无情的洗刷着玻璃
 *         莫不作声
 *         弥漫着污浊尘埃的天空也望不到顶
 *         手里的代码滴答敲个不停
 *         北国来的一阵冷风跨过几个莫名的省
 *         越过山峰的挺拔与小溪的逶迤
 *         也吹乱了我凌乱焦灼的心
 */
@RestController
@RequestMapping("/upload/picCloud")
@CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
public class UploadController {
    private static Logger logger = LoggerFactory.getLogger(UploadController.class);

    @Value("${cloud.server.appId}")
    private int appId;
    @Value("${cloud.server.secretId}")
    private String secretId;
    @Value("${cloud.server.secretKey}")
    private String secretKey;
    @Value("${cloud.server.bucket}")
    private String bucket;

    @Reference(version = "1.0.0")
    private UploadService uploadService;

    /**
     * 上传图片by Base64
     *
     * @param reqMap resp
     * @return BaseImgModer
     * @throws IllegalStateException
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/imgUploadByBase64", method = RequestMethod.POST)
    public void imgUploadByBase64(@RequestBody Map<String, Object> reqMap, @Context HttpServletResponse resp) {
        BaseResponse baseResponse = new BaseResponse();
        String imgFile = null;
        if (reqMap != null && !reqMap.isEmpty()) {
            imgFile = reqMap.get("imgFile").toString();
        }
        if (StringUtils.isEmpty(imgFile)) {
            baseResponse.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            baseResponse.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        } else {
            byte[] byteData = GenerateImage(imgFile);
            if (null != byteData) {
                if (byteData.length > Commond.MAX_PICSIZE) {
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_8003.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_8003.getValue());
                    logger.info("imgUploadByBase64 return date is : " + JsonUtil.objectToJson(baseResponse));
                    HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
                    return;
                }
                ByteArrayInputStream fileStream = new ByteArrayInputStream(byteData);
                UploadResult uInfo = saveToclond(fileStream);
                if (null != uInfo) {
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_1000.getValue());
                    baseResponse.setDataInfo(uInfo);
                }
                logger.info("uInfo date is: " + JsonUtil.objectToJson(uInfo));
            } else {
                baseResponse.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                baseResponse.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        }
        logger.info("imgUploadByBase64 return date is : " + JsonUtil.objectToJson(baseResponse));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
    }

    /**
     * 根据字节数组字符串进行Base64解码 保存为字节数组
     *
     * @param imgStr
     * @return
     */
    public static byte[] GenerateImage(String imgStr) {
        // 文件字节数组字符串数据为空
        if (imgStr == null) {
            return null;
        }
        BASE64Decoder decoder = new BASE64Decoder();
        try {
            // Base64解码
            return decoder.decodeBuffer(imgStr);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 上传图片by文件流
     *
     * @param request MultipartHttpServletRequest
     * @return BaseImgModer
     * @throws IllegalStateException
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/imgUpload", method = RequestMethod.POST)
    public void imgUpload(@Context MultipartHttpServletRequest request, @Context HttpServletResponse resp) {
        BaseResponse baseResponse = new BaseResponse();
        if (StringUtils.isEmpty(request)) {
            baseResponse.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            baseResponse.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        } else {
            //获得文件
            MultipartFile file = request.getFile("file");
            if (null != file) {
                //超过10MB
                if (file.getSize() > Commond.MAX_PICSIZE) {
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_8003.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_8003.getValue());
                    logger.info("imgUpload return date is : " + JsonUtil.objectToJson(baseResponse));
                    HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
                    return;
                }
                try {
                    InputStream input = file.getInputStream();
                    UploadResult uInfo = saveToclond(input);
                    logger.info("uInfo date is: " + JsonUtil.objectToJson(uInfo));
                    baseResponse.setDataInfo(uInfo);
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_1000.getValue());
                } catch (IOException e) {
                    e.printStackTrace();
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_1005.getValue());
                }
            }
        }
        logger.info("imgUpload return date is : " + JsonUtil.objectToJson(baseResponse));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
    }

    /**
     * 上传多张图片by文件流
     *
     * @param
     * @return BaseImgModer
     * @throws IllegalStateException
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/imgUploadByMany", method = RequestMethod.POST)
    public void imgUploadByMany(@Context MultipartHttpServletRequest request, @Context HttpServletResponse resp) {
        BaseResponse baseResponse = new BaseResponse();
        logger.info("request is： " + request);
        List<UploadResult> uInfoList = new ArrayList<UploadResult>();
        if (StringUtils.isEmpty(request)) {
            baseResponse.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            baseResponse.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        } else {
            try {
                List<MultipartFile> files = request.getFiles("file");
                logger.info("files is： " + files);
                if (StringUtils.isEmptyList(files)) {
                    baseResponse.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
                    baseResponse.setMessage(ReturnCodeEnum.CODE_1006.getValue());
                } else {
                    for (MultipartFile file : files) {
                        //超过10MB 返回失败
                        if (file.getSize() > Commond.MAX_PICSIZE) {
                            baseResponse.setReturnCode(ReturnCodeEnum.CODE_8003.getCode());
                            baseResponse.setMessage(ReturnCodeEnum.CODE_8003.getValue());
                            logger.info("imgUploadByMany return date is : " + JsonUtil.objectToJson(baseResponse));
                            HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
                            return;
                        }
                        UploadResult uInfo = saveToclond(file.getInputStream());
                        uInfoList.add(uInfo);
                        baseResponse.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                        baseResponse.setMessage(ReturnCodeEnum.CODE_1000.getValue());
                        baseResponse.setDataInfo(uInfoList);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                baseResponse.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                baseResponse.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        }
        logger.info("imgUploadByMany return date is : " + JsonUtil.objectToJson(baseResponse));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
    }

    private UploadResult saveToclond(InputStream inputStream) {
        PicCloud pc = new PicCloud(appId, secretId, secretKey, bucket);
        //PicCloud pc = new PicCloud(10029968, "AKIDqsaEahj8KP5ufFLOMDACd4TFUZqsp4j3", "WaCdUBCZOIGt7A5uR9acBcRlLKSRLKhZ", "upload007");
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(inputStream)) {
            return uInfo;
        } else {
            try {
                uInfo = pc.upload(inputStream);
                if (uInfo != null) {
                    System.out.println("upload pic success");
                    logger.info("upLoadImg success");
                } else {
                    System.out.println("upload pic error, error=" + pc.getError());
                    logger.info("upLoadImg error, info is: " + pc.getError());
                }
            } catch (Exception e) {
                logger.error("upload error: " + e.getMessage(), e);
            } finally {
                if (null != inputStream) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return uInfo;
        }
    }

    /**
     * 上传图片by二维码
     *
     * @param requestUpload
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/imgTwoDimensionUpload", method = RequestMethod.POST)
    public void imgTwoDimensionUpload(@RequestBody RequestUpload requestUpload, @Context HttpServletResponse resp) {
        BaseResponse<UploadResult> response = new BaseResponse<UploadResult>();
        if (null != requestUpload && null != requestUpload.getCode()) {
            UploadResult result = uploadService.uploadTwoDimensionImg(requestUpload.getCode());
            if (null != result) {
                response.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1000.getValue());
                response.setDataInfo(result);
            } else {
                response.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        } else {
            response.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            response.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        }
        logger.info("imgTwoDimensionUpload return date is : " + JsonUtil.objectToJson(response));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(response));
    }

    /**
     * 生成图片by验证码
     *
     * @param requestUpload
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/imgValidateCodeUpload", method = RequestMethod.POST)
    public void imgValidateCodeUpload(@RequestBody RequestUpload requestUpload, @Context HttpServletResponse resp) {
        BaseResponse<UploadResult> response = new BaseResponse<UploadResult>();
        if (null != requestUpload) {
            //生成验证码
            String code = ValidateCode.random(5);
            UploadResult result = uploadService.uploadValidateCodeImg(code);
            if (null != result) {
                // 生成图片路径 与验证码 缓存 到redis
                response.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1000.getValue());
                response.setDataInfo(result);
            } else {
                response.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        } else {
            response.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            response.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        }
        logger.info("imgValidateCodeUpload return date is : " + JsonUtil.objectToJson(response));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(response));
    }

    /**
     * 删除图片
     *
     * @param requestUpload
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/deleteImg", method = RequestMethod.POST)
    public void deleteImg(@RequestBody RequestUpload requestUpload, @Context HttpServletResponse resp) {
        BaseResponse response = new BaseResponse();
        logger.info("deleteImg 入参是：" + JsonUtil.objectToJson(requestUpload));
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(requestUpload) || StringUtils.isEmpty(requestUpload.getFileId())) {
            response.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            response.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        } else {
            Boolean deleteFlag = uploadService.deleteFile(requestUpload.getFileId());
            if (deleteFlag) {
                response.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1000.getValue());
            } else {
                response.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        }
        logger.info("deleteImg return date is : " + JsonUtil.objectToJson(response));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(response));
    }

    /**
     * 上传图片by Base64
     *
     * @param imgFile resp
     * @return BaseImgModer
     * @throws IllegalStateException
     */
   /* public static void img(String imgFile) {
        BASE64Decoder decoder = new BASE64Decoder();
        byte[] byteData = GenerateImage(imgFile);
        if (byteData != null) {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(byteData);
            UploadResult uInfo = saveToclond(inputStream);
            logger.info("uInfo: " + uInfo);
        }
    }

    public static void main(String[] args) throws Exception {//将图片文件转化为字节数组字符串，并对其进行Base64编码处理
        //读取图片字节数组
        try {
            InputStream in = new FileInputStream("E:/test123.png");
            byte[] data = new byte[in.available()];
            in.read(data);
            //对字节数组Base64编码
            BASE64Encoder encoder = new BASE64Encoder();
            encoder.encode(data);//返回Base64编码过的字节数组字符串
            img(encoder.encode(data));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}