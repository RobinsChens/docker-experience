package cn.vpclub.upload.manager.consumer.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * Created by  vpclub on 16-7-31.
 * PackageName cn.vpclub.upload.manager.common
 * ModifyDate  16-7-31
 * Description (常量)
 * ProjectName vp-upload-manager
 */
@Component
public class CommonSystant {
    public static final int MAX_PICSIZE = 2 * 1024 *1024;
    @Value("${fastdfs.storage}")
    private String domain;

    public String getDomain() {
        return domain;
    }
}
