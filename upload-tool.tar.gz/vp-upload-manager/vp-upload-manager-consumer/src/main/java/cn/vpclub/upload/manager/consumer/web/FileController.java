package cn.vpclub.upload.manager.consumer.web;

import cn.vpclub.common.config.api.model.response.BaseResponse;
import cn.vpclub.common.config.common.utils.*;
import cn.vpclub.upload.manager.api.model.UploadResult;
import cn.vpclub.upload.manager.api.model.request.RequestUpload;
import cn.vpclub.upload.manager.common.utils.ReturnCodeEnum;
import cn.vpclub.upload.manager.common.utils.StringUtils;
import cn.vpclub.upload.manager.consumer.constant.CommonSystant;
import cn.vpclub.upload.manager.consumer.fastdfs.FastDfsClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.io.IOException;
import java.util.Map;

/**
 * 文件处理
 */
@RestController
@RequestMapping("/common/api/file")
@CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
public class FileController {
    private static Logger logger = LoggerFactory.getLogger(FileController.class);

    @Autowired
    private CommonSystant commonSystant;
    /**
     * 上传
     *
     * @param request request
     * @return BaseImgModer
     * @throws IllegalStateException
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public void uploadFileByByte(@Context MultipartHttpServletRequest request, @Context HttpServletResponse resp) {
        BaseResponse baseResponse = new BaseResponse();

        Map requestParam = MapParserUtil.getAllRequestParam(request);

        if (StringUtil.isEmpty(request)) {
            baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1006.getCode());
            baseResponse.setMessage(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1006.getValue());
        } else {
            //获得文件
            MultipartFile file = request.getFile("fileData");
            String fileId = null;
            if (null != file) {
                //超过2MB
                if (file.getSize() > CommonSystant.MAX_PICSIZE) {
                    baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getCode());
                    baseResponse.setMessage("上传文件请控制在2M内");
                    logger.info("uploadFile return date is : " + JsonUtil.objectToJson(baseResponse));
                    HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));
                    return;
                }
                try {
                    UploadResult uInfo = null;
                    //调用业务接口
                    fileId = FastDfsClient.uploadFileByByte(file.getBytes(), file.getName());
                    if (StringUtil.isNotEmpty(fileId)){
                        uInfo = new UploadResult();
                        uInfo.setFileId(fileId);
                        uInfo.setUrl(commonSystant.getDomain()+"/"+fileId);
                    }
                    logger.info("uploadFile return date is: " + JsonUtil.objectToJson(uInfo));
                    baseResponse.setDataInfo(uInfo);
                    if (uInfo != null) {
                        baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1000.getCode());
                        baseResponse.setMessage("上传"+cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1000.getValue());
                    } else {
                        baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getCode());
                        baseResponse.setMessage(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getValue());
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                    baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getCode());
                    baseResponse.setMessage(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getValue());
                }
            }
            else{
                baseResponse.setReturnCode(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getCode());
                baseResponse.setMessage(cn.vpclub.common.config.common.enums.ReturnCodeEnum.CODE_1005.getValue());
            }

        }
        logger.info("uploadFile return date is : " + JsonUtil.objectToJson(baseResponse));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(baseResponse));

    }

    /**
     * 删除文件
     *
     * @param requestUpload
     */
    @CrossOrigin(allowedHeaders = "*", allowCredentials = "true")
    @RequestMapping(value = "/deleteImg", method = RequestMethod.POST)
    public void deleteImg(@RequestBody RequestUpload requestUpload, @Context HttpServletResponse resp) {
        BaseResponse response = new BaseResponse();
        logger.info("deleteImg 入参是：" + JsonUtil.objectToJson(requestUpload));
        UploadResult uInfo = null;
        if (StringUtils.isEmpty(requestUpload) || StringUtils.isEmpty(requestUpload.getFileId())) {
            response.setReturnCode(ReturnCodeEnum.CODE_1006.getCode());
            response.setMessage(ReturnCodeEnum.CODE_1006.getValue());
        } else {
            int deleteFlag = FastDfsClient.deleteFile(requestUpload.getFileId());
            if (deleteFlag == 0) {
                response.setReturnCode(ReturnCodeEnum.CODE_1000.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1000.getValue());
            } else {
                response.setReturnCode(ReturnCodeEnum.CODE_1005.getCode());
                response.setMessage(ReturnCodeEnum.CODE_1005.getValue());
            }
        }
        logger.info("deleteImg return date is : " + JsonUtil.objectToJson(response));
        HttpResponseUtil.setResponseBody(resp, JsonUtil.objectToJson(response));
    }

}